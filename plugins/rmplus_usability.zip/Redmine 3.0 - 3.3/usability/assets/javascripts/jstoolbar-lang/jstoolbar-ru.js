jsToolBar.strings['Cut'] = 'Спрятать содержимое';
jsToolBar.strings['us_text_color'] = 'Цвет текста';