resources :issues do
  member do
    get 'rit_history'
  end
end
