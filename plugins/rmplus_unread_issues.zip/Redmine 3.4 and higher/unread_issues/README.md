## Unread issues

#### Plugin for Redmine

The plugin implements a convenient functionality of monitoring changes in issues.
Read more on http://rmplus.pro/redmine/plugins/unread_issues

Another plugins of our team you can see on site http://rmplus.pro

changelog:
  2.2.1
    * Fixed: mobile view
  2.2.0
    * Added: support redmine 3.4
    * Removed: support redmine below 3.4
    * Moved to ajax counters by a_common_libs
  2.1.3
    * Fixed: minor bugs
  2.1.2
    * Fixed: my issues link
  2.1.1
    * Added: support new ajax_counters
    * added french localization
  2.1.0:
    * fixed unread filters to new logic
  2.0.0:
    * removed logic by assigned_to
    * refactored counters
  1.5.0:
    * support Redmine 3.0
  2015-01-29:
    * minor fixes
    * tested support Redmine 2.6
