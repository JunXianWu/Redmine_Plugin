## AjaxCounters

#### Plugin for Redmine

#### Copyright
Copyright (c) 2011-2013 Danil Kukhlevskiy, Vladimir Pitin.

Another plugins of our team you can see on site http://rmplus.pro

Changelog:
1.5.1:
* Added: bypass creating session by API request (redmine bug)
1.5.0:
* rewritten to localStorage to minimize count of requests to server
1.4.0:
* added gem for session store only for rails 4.0
1.3.0:
* fix working with relative references
1.2.0:
* support RM3
* some small improvements
1.1.0:
* fixed js break for counters
